import ReactDom from 'react-dom';

ReactDom.render({
  <>,
  document.getElementById('reactApp');
});
